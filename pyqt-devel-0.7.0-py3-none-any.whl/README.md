# Scrux ClipLab

ClipLab is Scrux's local replay-data workspace. Its recommended workflow records authoritative full-world state from a local game server, stores it as compressed one-minute chunks, and reconstructs any player's perspective after the game.

For the complete recording, replay, schema, ML research, archiving, and troubleshooting workflow, read:

- [ClipLab Local Replay and ML Research Guide](../docs/cliplab-local-ml-research-guide.md)

## Quick start

From the repository root, start Scrux:

```powershell
npm run local
```

In a second terminal, start ClipLab:

```powershell
npm run clip-lab
```

Open:

```text
http://127.0.0.1:8787
```

For the first test:

1. Use `ws://localhost:8440` for FFA.
2. Leave the protocol on `Modern`.
3. Record for 1 minute.
4. Select the saved full-world replay.
5. Confirm that the timeline, full map, and player perspective selector work.

The normal local game client is:

```text
http://127.0.0.1:1234
```

## What full-world captures provide

- Every included world cell, including positions, sizes, ownership, appearance, and boost state.
- Player score, owned-cell IDs, recorded view/camera, router type, and team.
- World borders and aggregate cell/player counts.
- Server ticks and timestamps.
- Delta compression, periodic keyframes, and one-minute gzip chunks.
- Full-map and follow-player replay cameras.
- Heuristic kill, split, mass-swing, X-split, and virus-event candidates.
- Saved highlight metadata for curated review windows.

The full-world data is recorded inside the server and is protocol-neutral. `Modern` remains the recommended client/server mode for current local play; selecting a protocol does not change the saved world-capture schema.

## Storage

Captures are written to:

```text
ClipLab/captures/
```

Current recordings normally create:

```text
<capture-id>.scruxworld-index.json
<capture-id>.part-000000.scruxworld-chunk.json.gz
<capture-id>.part-000001.scruxworld-chunk.json.gz
...
<capture-id>.world-summary.json
```

Keep every file sharing the capture ID together. For chunked recordings, the download link returns the index rather than packaging all chunks into one file.

The maximum duration for one recording is 24 hours. Multi-day studies should use multiple recordings and a separate session manifest.

## Important limitation for ML research

Current full-world captures record the resulting game state. They do not yet record exact mouse coordinates, split/eject button timestamps, model observations, selected actions, rewards, logits, or checkpoint state.

Movement headings and events can be inferred from trajectories, owned-cell changes, boost state, and nearby world changes, but those are proxy labels rather than exact controls. The full guide explains how to retain confidence labels and avoid data leakage when building a human-vs-bot benchmark.

## Legacy viewer-packet captures

ClipLab also contains the earlier spectator packet recorder and client-clip conversion code. Those captures store the packets delivered to one spectator connection and use:

```text
<capture-id>.scruxreplay.json.gz
<capture-id>.summary.json
```

Use the full-world recorder for new behavioural research because it can reconstruct every participant rather than only one connection's visible stream.

## Tests

From the repository root:

```powershell
npm run clip-lab:test
```

## Local-only control

The game server's capture-control endpoints require loopback access and `LOCAL_DEV_MODE`. They intentionally return `404` outside local development. ClipLab is not a public production recording endpoint.
